#ifndef ADP2000_H
#define ADP2000_H

#include <Wire.h>

#define ADP2000_I2C_ADDRESS 0x25  // 7-bit I2C address for the ADP2000
#define CONTINUOUS_MEASUREMENT_CMD 0x361E
#define SINGLE_MEASUREMENT_CMD 0x372D
#define PRODUCT_TYPE_CMD 0xE201

// Scaling factors
#define PRESSURE_SCALE_FACTOR 240.0
#define TEMPERATURE_SCALE_FACTOR 200.0

class ADP2000 {
public:
    ADP2000(TwoWire &wire = Wire);

    bool begin();
    float readPressure();
    float readTemperature();
    bool verifyProductType();

private:
    TwoWire &_wire;
    void sendCommand(uint16_t command);
    bool readSensorData(uint8_t *data, size_t length);
    float convertPressure(int16_t rawValue);
    float convertTemperature(int16_t rawValue);
    uint8_t calculateCRC8(uint8_t *data, size_t length);
};

#endif