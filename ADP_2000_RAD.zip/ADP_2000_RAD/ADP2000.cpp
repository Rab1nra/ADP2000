#include "ADP2000.h"

ADP2000::ADP2000(TwoWire &wire) : _wire(wire) {}

bool ADP2000::begin() {
    _wire.begin();

    // Verify product type
    uint8_t productData[3];
    sendCommand(PRODUCT_TYPE_CMD);
    if (!readSensorData(productData, sizeof(productData))) {
        return false;
    }

    return productData[0] == 0x41 && productData[1] == 0x53;
}

float ADP2000::readPressure() {
    uint8_t measurementData[6];
    sendCommand(CONTINUOUS_MEASUREMENT_CMD);
    delay(10); // Wait for measurement to complete

    if (!readSensorData(measurementData, sizeof(measurementData))) {
        return NAN;
    }

    // Validate CRC
    if (calculateCRC8(measurementData, 2) != measurementData[2] ||
        calculateCRC8(&measurementData[3], 2) != measurementData[5]) {
        return NAN;
    }

    int16_t rawPressure = (measurementData[0] << 8) | measurementData[1];
    return convertPressure(rawPressure);
}

float ADP2000::readTemperature() {
    uint8_t measurementData[6];
    sendCommand(CONTINUOUS_MEASUREMENT_CMD);
    delay(10); // Wait for measurement to complete

    if (!readSensorData(measurementData, sizeof(measurementData))) {
        return NAN;
    }

    // Validate CRC
    if (calculateCRC8(measurementData, 2) != measurementData[2] ||
        calculateCRC8(&measurementData[3], 2) != measurementData[5]) {
        return NAN;
    }

    int16_t rawTemperature = (measurementData[3] << 8) | measurementData[4];
    return convertTemperature(rawTemperature);
}

bool ADP2000::readSensorData(uint8_t *data, size_t length) {
    _wire.requestFrom(ADP2000_I2C_ADDRESS, length);
    for (size_t i = 0; i < length; i++) {
        if (_wire.available()) {
            data[i] = _wire.read();
        } else {
            return false;
        }
    }
    return true;
}

void ADP2000::sendCommand(uint16_t command) {
    _wire.beginTransmission(ADP2000_I2C_ADDRESS);
    _wire.write(command >> 8); // High byte
    _wire.write(command & 0xFF); // Low byte
    _wire.endTransmission();
}

float ADP2000::convertPressure(int16_t rawValue) {
    return rawValue / PRESSURE_SCALE_FACTOR;
}

float ADP2000::convertTemperature(int16_t rawValue) {
    return rawValue / TEMPERATURE_SCALE_FACTOR;
}

uint8_t ADP2000::calculateCRC8(uint8_t *data, size_t length) {
    uint8_t crc = 0xFF;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8; bit++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ 0x31;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}
